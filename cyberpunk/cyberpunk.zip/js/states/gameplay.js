var time = 10,
	timerHud = doc.getElementById("time"),
	preCounterHud = doc.getElementById("preCounter"),
	preCounterMsg = ["3","2","1","GO", ""];

function preCounter(i){
	if(i<preCounterMsg.length){
		preCounterHud.innerHTML = preCounterMsg[i];
		i++;

		setTimeout(function(){
			preCounter(i);
		}, 1000);
	}else{
		countdown();
	}
}

function countdown(){
	if(time > 0){
		time--;
		timerHud.innerHTML = time;
		setTimeout(function(){
			return countdown(time, timerHud);
		}, 1000);		
	}else{
		return time;
	}
}

gameplay = gamvas.State.extend({
	preCounter: 3,
	time: 10,
	timerHud: null,
	door: null,
	init: function(){
		this.camera.setPosition(400,400);
		this.door = new doorActor("door", 368, 716);

		this.addActor(this.door);
		timerHud.innerHTML = time;

		preCounter(0);
		//countdown();
	},

	draw: function(){
		if(this.time == 0){
			alert("acabou");
		}
	}
});

gamvas.event.addOnLoad(function(){
	gamvas.state.addState(new gameplay("gameplay"));
});